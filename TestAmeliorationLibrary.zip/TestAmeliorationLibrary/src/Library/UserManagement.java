package Library;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Iterator;

public class UserManagement {

	private final String UserListURL = "./users.dat";
	private ArrayList<User> userList;
	private static UserManagement instance = null;
	
	private UserManagement() 
	{
		userList = new ArrayList<User>();
	}
	
	public static UserManagement getInstance() {
		if(UserManagement.instance == null)
		{
			UserManagement.instance = new UserManagement();
		}
		return UserManagement.instance;
	}
	
	public void saveUsers() throws IOException{
		
		FileOutputStream fout = new FileOutputStream(UserListURL);
		ObjectOutputStream oos = new ObjectOutputStream(fout);
		oos.writeObject(userList);
		oos.close();
	}
	
	@SuppressWarnings("unchecked")
	void loadUsers() throws Exception{
		
		FileInputStream fis = new FileInputStream(UserListURL);
	    ObjectInputStream ois = new ObjectInputStream(fis);
	    userList = (ArrayList<User>)ois.readObject();
	    ois.close();
	}
	
	public User login(String userName, String password){
		
		User currentUser = null; //initialize
		Iterator<User> userItr = userList.iterator();
		while(userItr.hasNext()){
			User tempUser = userItr.next();
			if(tempUser.getUserName().equals(userName) && tempUser.getPassword().equals(password)){
				currentUser = tempUser;
				break;
			}//if login successful
		}//while
		return currentUser; //return null if login failed.
	}
	
	boolean addUser(User user){
		return userList.add(user);
	}
	
	boolean updateUser(int userId, User user){
		if(user == null){
			return false;
		}
		Iterator<User> userItr = userList.iterator();
		int index = -1;
		while(userItr.hasNext()){
			User tempUser = userItr.next();
			index++;
			if(tempUser.getUserId()==userId){
				userList.set(index, user);
				return true;
			}//end if
		}//end while
		
		return false;
	}//update user
	
	boolean deleteUser(int userId){
		
		Iterator<User> userItr = userList.iterator();
		int index = -1;
		while(userItr.hasNext()){
			User tempUser = userItr.next();
			index++;
			if(tempUser.getUserId()==userId){
				//******************************
				//modified by Sen Li after demo
				//users who hold rented books can not be deleted.
				/*Iterator<Book> bookItr = BookManagement.getInstance().getBookList().iterator();
				while(bookItr.hasNext()){
					if(bookItr.next().getOwnerId() == userId)
						return false;
				}//end while
				*/
				//******************************
				userList.remove(index);
				return true;
			}//end if
		}//end while
		return false;
				
	}//delete user
	
	public ArrayList<User> getUserList(){
		
		return userList;
	}//show all user
}
