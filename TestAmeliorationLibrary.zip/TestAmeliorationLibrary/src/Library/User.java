package Library;

import java.io.Serializable;
import java.util.ArrayList;

public class User implements Serializable {
	
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/**
	 */
	private int userId;
	/**
	 */
	private String userName;
	/**
	 */
	private String password;
	/**
	 */
	private String phoneNo;
	/**
	 */
	private String address;
	/**
	 */
	private boolean isAdmin;
	/**
	 */
	private ArrayList<Category> subscribedCategory;
	
	//getters & setters 
	/**
	 * @return
	 */
	public int getUserId() {
		return userId;
	}
	/**
	 * @param userId
	 */
	public void setUserId(int userId) {
		this.userId = userId;
	}
	/**
	 * @return
	 */
	public String getUserName() {
		return userName;
	}
	/**
	 * @param userName
	 */
	public void setUserName(String userName) {
		this.userName = userName;
	}
	/**
	 * @return
	 */
	public String getPassword() {
		return password;
	}
	/**
	 * @param password
	 */
	public void setPassword(String password) {
		this.password = password;
	}
	/**
	 * @return
	 */
	public String getPhoneNo() {
		return phoneNo;
	}
	/**
	 * @param phoneNo
	 */
	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}
	/**
	 * @return
	 */
	public String getAddress() {
		return address;
	}
	/**
	 * @param address
	 */
	public void setAddress(String address) {
		this.address = address;
	}
	/**
	 * @return
	 */
	public boolean isAdmin() {
		return isAdmin;
	}
	public void setAdmin(boolean isAdmin) {
		this.isAdmin = isAdmin;
	}
	
	public ArrayList<Category> getSubscribedCategory() {
		return subscribedCategory;
	}
	public void setSubscribedCategory(ArrayList<Category> subscribedCategory) {
		this.subscribedCategory = subscribedCategory;
	}
	
}
