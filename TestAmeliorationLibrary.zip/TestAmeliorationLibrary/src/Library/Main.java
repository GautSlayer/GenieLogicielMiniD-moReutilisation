package Library;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		User u1 = new User(); //admin
		User u2 = new User(); //user1
		User u3 = new User(); //user2

		u1.setUserId(1);
		u1.setPassword("1");
		u1.setUserName("admin");
		u1.setAdmin(true);
		
		u2.setUserId(2);
		u2.setPassword("123");
		u2.setUserName("user");
		u2.setAdmin(false);
		
		u3.setUserId(3);
		u3.setPassword("123");
		u3.setUserName("user2");
		u3.setAdmin(false);
		
		UserManagement userManage = UserManagement.getInstance();
		userManage.addUser(u1);
		userManage.addUser(u2);
		userManage.addUser(u3);
		
		new FrmCustomerLogin();
	}

}
